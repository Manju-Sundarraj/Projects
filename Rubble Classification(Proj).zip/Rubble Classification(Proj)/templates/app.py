import os
from flask import Flask, render_template, request,url_for
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image

app = Flask(__name__ )
model = load_model('templates\garbage_classification_model.h5')

@app.route('/')
def garbage():
    return render_template('garbage.html')

@app.route('/predict', methods=['POST','GET'])
def predict():
    # Get the uploaded file from the request
    f = request.files['image']
    # Save the file to a folder
    file_path = os.path.join('predictions', f.filename)
    f.save(file_path)

    # Preprocess the image
    img = image.load_img(file_path, target_size=(150, 150))
    x = image.img_to_array(img) / 255.0
    x = x.reshape((1,) + x.shape)

    # Make predictions using the model
    prediction = model.predict(x)
    classes = ['cardboard', 'glass', 'metal', 'paper', 'plastic', 'trash']
    predicted_class = classes[prediction.argmax()]

    # Pass the predicted class to the HTML template for display
    return render_template('garbage.html', prediction=predicted_class)

if __name__ == '__main__':
    app.run(debug=True)
