// Show footer when content exceeds viewport height
window.addEventListener("DOMContentLoaded", function () {
  var body = document.body;
  var footer = document.querySelector("footer");

  function showFooter() {
    if (body.offsetHeight < window.innerHeight) {
      body.classList.remove("show-footer");
    } else {
      body.classList.add("show-footer");
    }
  }

  showFooter();

  window.addEventListener("resize", function () {
    showFooter();
  });

  // Scroll to About section when clicking on the About button
  var aboutButton = document.querySelector('nav li a[href="#about"]');
  var homeButton = document.querySelector('nav li a[href="#"]');

  aboutButton.addEventListener("click", function (event) {
    event.preventDefault();
    aboutSection.scrollIntoView({ behavior: "smooth", block: "start" });
  });
  homeButton.addEventListener("click", function (event) {
    event.preventDefault();
    alert("Returning to the main page!");
    // Redirect to the main page
    window.location.href = "garbage.html";
  });
});